import { useState } from "react";

function SearchBar() {
  const [product, setProduct] = useState("");

  const handleSearch = async () => {
    if (product.trim() === "") {
      alert("Please enter product name");
      return;
    }

    try {
      const response = await fetch(
        `http://127.0.0.1:5000/search?product=${product}`
      );

      const data = await response.json();

      console.log(data);

      alert("Reviews Scraped Successfully");
    } catch (err) {
      console.log(err);
      alert("Error while scraping");
    }
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Search Product..."
        value={product}
        onChange={(e) => setProduct(e.target.value)}
      />

      <button onClick={handleSearch}>
        Search
      </button>
    </div>
  );
}

export default SearchBar;